//
//  SignupResponseModel.swift
//  PhotoApp
//
//  Created by Sergey Kargopolov on 2020-03-05.
//  Copyright © 2020 Sergey Kargopolov. All rights reserved.
//

import Foundation

struct SignupResponseModel: Decodable {
    let status: String
}
